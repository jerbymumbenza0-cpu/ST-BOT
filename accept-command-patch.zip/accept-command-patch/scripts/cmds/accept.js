module.exports = {
  config: {
    name: "accept",
    aliases: ["acceptfriend"],
    version: "2.0.0",
    author: "ST-BOT / Jerby",
    countDown: 5,
    role: 2,
    description: "Afficher et accepter les demandes d'amis reçues",
    category: "owner",
    guide: "{pn} - afficher les demandes capturées\n{pn} 1 - accepter la demande n°1\n{pn} all - accepter toutes les demandes"
  },

  onStart: async function ({ api, message, event, args, commandName }) {
    // Les demandes sont enregistrées par handlerAction quand Facebook envoie
    // l'événement friend_request_received.
    if (!global.GoatBot.friendRequests) {
      global.GoatBot.friendRequests = new Map();
    }

    const requestsMap = global.GoatBot.friendRequests;
    const requests = Array.from(requestsMap.values());

    if (requests.length === 0) {
      return message.reply(
        "📭 Aucune demande d'ami n'a été capturée depuis le démarrage du bot.\n\n" +
        "⚠️ La version FCA installée ne fournit pas de méthode publique documentée " +
        "pour récupérer rétroactivement toute la boîte des demandes. Les nouvelles " +
        "demandes seront ajoutées à cette liste lorsqu'elles arrivent pendant que le bot tourne."
      );
    }

    // Récupérer les noms pour rendre la liste lisible. L'ID reste disponible
    // si Facebook ne renvoie pas les informations du profil.
    let userInfo = {};
    try {
      const ids = requests.map(item => String(item.userID));
      userInfo = await api.getUserInfo(ids) || {};
    } catch (error) {
      console.warn("[accept] Impossible de récupérer les noms des demandeurs:", error.message);
    }

    const list = requests.map((item, index) => {
      const profile = userInfo[item.userID] || userInfo[String(item.userID)] || {};
      return {
        userID: String(item.userID),
        name: profile.name || item.name || "Profil Facebook",
        index: index + 1
      };
    });

    const choice = String(args[0] || "").toLowerCase();
    if (choice === "all") {
      return acceptRequests({ api, message, event, requests: list, selected: list, requestsMap });
    }

    if (choice) {
      const number = Number(choice);
      if (!Number.isInteger(number) || number < 1 || number > list.length) {
        return message.reply(`❌ Numéro invalide. Choisis un nombre entre 1 et ${list.length}, ou utilise « accept all ».`);
      }
      return acceptRequests({ api, message, event, requests: list, selected: [list[number - 1]], requestsMap });
    }

    let text = "📩 DEMANDES D'AMIS REÇUES\n━━━━━━━━━━━━━━━━━━\n";
    list.forEach((item, index) => {
      text += `\n${index + 1}. ${item.name}\n   ID: ${item.userID}\n`;
    });
    text += "\n━━━━━━━━━━━━━━━━━━\n";
    text += "Réponds à ce message avec :\n";
    text += "• un numéro (ex. 1) pour accepter une demande\n";
    text += "• all pour toutes les accepter\n";
    text += "• cancel pour annuler\n\n";
    text += "⚠️ Seules les demandes reçues pendant que le bot est en ligne apparaissent ici.";

    return message.reply(text, (err, info) => {
      if (err || !info) return;
      global.GoatBot.onReply.set(info.messageID, {
        commandName,
        messageID: info.messageID,
        author: String(event.senderID),
        type: "friendRequestList",
        requests: list
      });
    });
  },

  onReply: async function ({ api, message, event, Reply }) {
    if (String(event.senderID) !== String(Reply.author)) {
      return message.reply("❌ Seule la personne qui a ouvert cette liste peut la confirmer.");
    }

    const answer = String(event.body || "").trim().toLowerCase();
    if (answer === "cancel" || answer === "annuler" || answer === "c") {
      global.GoatBot.onReply.delete(Reply.messageID);
      return message.reply("✅ Opération annulée. Aucune demande n'a été acceptée.");
    }

    const requestsMap = global.GoatBot.friendRequests || new Map();
    const requests = Reply.requests || [];
    let selected;

    if (answer === "all") {
      selected = requests;
    } else {
      const number = Number(answer);
      if (!Number.isInteger(number) || number < 1 || number > requests.length) {
        return message.reply(`❌ Réponse invalide. Envoie un numéro entre 1 et ${requests.length}, « all » ou « cancel ».`);
      }
      selected = [requests[number - 1]];
    }

    await acceptRequests({ api, message, event, requests, selected, requestsMap });
    global.GoatBot.onReply.delete(Reply.messageID);
  }
};

async function acceptRequests({ api, message, selected, requestsMap }) {
  if (typeof api.handleFriendRequest !== "function") {
    return message.reply("❌ Cette version de l'API ne possède pas la méthode handleFriendRequest().");
  }

  let accepted = 0;
  const failed = [];

  for (const request of selected) {
    try {
      // FCA 4.x documente handleFriendRequest(userID, true) pour accepter.
      await api.handleFriendRequest(String(request.userID), true);
      requestsMap.delete(String(request.userID));
      accepted++;
    } catch (error) {
      failed.push(`${request.name || request.userID} (${request.userID})`);
      console.error(`[accept] Échec pour ${request.userID}:`, error);
    }
  }

  let result = `✅ ${accepted} demande(s) acceptée(s).`;
  if (failed.length) {
    result += `\n\n❌ Échec pour :\n${failed.join("\n")}`;
  }
  return message.reply(result);
}
