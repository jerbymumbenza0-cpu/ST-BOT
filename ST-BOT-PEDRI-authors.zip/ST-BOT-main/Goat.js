process.on('unhandledRejection', error => console.log(error));
process.on('uncaughtException', error => console.log(error));

const axios = require("axios");
const fs = require("fs-extra");
const { execSync } = require('child_process');
const log = require('./logger/log.js');
const path = require("path");
global.File = class File {};

function validJSON(pathDir) {
  if (!fs.existsSync(pathDir))
    throw new Error(`File "${pathDir}" not found`);
  try {
    JSON.parse(fs.readFileSync(pathDir, "utf8"));
    return true;
  }
  catch (err) {
    throw new Error(err.message);
  }
}


const dirConfig = path.normalize(`${__dirname}/config.json`);
const dirConfigCommands = path.normalize(`${__dirname}/configCommands.json`);
const dirAccount = path.normalize(`${__dirname}/account.txt`);

for (const pathDir of [dirConfig, dirConfigCommands]) {
  try {
    validJSON(pathDir);
  }
  catch (err) {
    log.error("CONFIG", `Invalid JSON file "${pathDir.replace(__dirname, "")}":\n${err.message.split("\n").map(line => `  ${line}`).join("\n")}\nPlease fix it and restart bot`);
    process.exit(0);
  }
}
const config = require(dirConfig);
if (config.whiteListMode?.whiteListIds && Array.isArray(config.whiteListMode.whiteListIds))
  config.whiteListMode.whiteListIds = config.whiteListMode.whiteListIds.map(id => id.toString());
const configCommands = require(dirConfigCommands);

global.GoatBot = {
  startTime: Date.now() - process.uptime() * 1000, // time start bot (ms)
  commands: new Map(), // store all commands
  eventCommands: new Map(), // store all event commands
  commandFilesPath: [], // [{ filePath: "", commandName: [] }
  eventCommandsFilesPath: [], // [{ filePath: "", commandName: [] }
  aliases: new Map(), // store all aliases
  onFirstChat: [], // store all onFirstChat [{ commandName: "", threadIDsChattedFirstTime: [] }}]
  onChat: [], // store all onChat
  onEvent: [], // store all onEvent
  onReply: new Map(), // store all onReply
  onReaction: new Map(), // store all onReaction
  onAnyEvent: [], // store all onAnyEvent
  config, // store config
  configCommands, // store config commands
  envCommands: {}, // store env commands
  envEvents: {}, // store env events
  envGlobal: {}, // store env global
  reLoginBot: function () { }, // function relogin bot, will be set in bot/login/login.js
  Listening: null, // store current listening handle
  oldListening: [], // store old listening handle
  callbackListenTime: {}, // store callback listen
  storage5Message: [], // store 5 message to check listening loop
  fcaApi: null, // store fca api
  botID: null, // store bot id
};

// Initialize update tracking before async operations
global.GoatBot.updateAvailable = { hasUpdate: false, newVersion: null };
global.GoatBot.updateRefuseUntil = null;
global.updateAvailable = global.GoatBot.updateAvailable;
global.updateRefuseUntil = global.GoatBot.updateRefuseUntil;

global.db = {
  // all data
  allThreadData: [],
  allUserData: [],
  allDashBoardData: [],
  allGlobalData: [],

  // model
  threadModel: null,
  userModel: null,
  dashboardModel: null,
  globalModel: null,

  // handle data
  threadsData: null,
  usersData: null,
  dashBoardData: null,
  globalData: null,

  receivedTheFirstMessage: {}

  // all will be set in bot/login/loadData.js
};

global.client = {
  dirConfig,
  dirConfigCommands,
  dirAccount,
  countDown: {},
  cache: {},
  database: {
    creatingThreadData: [],
    creatingUserData: [],
    creatingDashBoardData: [],
    creatingGlobalData: []
  },
  commandBanned: configCommands.commandBanned,
  premiumRequests: []
};

const utils = require("./utils.js");
global.utils = utils;
const { colors } = utils;
global.GoatBot.stagent = require("./bot/stagent.js");
global.stagent = global.GoatBot.stagent;

global.temp = {
  createThreadData: [],
  createUserData: [],
  createThreadDataError: [], // Can't get info of groups with instagram members
  filesOfGoogleDrive: {
    arraybuffer: {},
    stream: {},
    fileNames: {}
  },
  contentScripts: {
    cmds: {},
    events: {}
  }
};

// watch dirConfigCommands file and dirConfig
const watchAndReloadConfig = (dir, type, prop, logName) => {
  let lastModified = fs.statSync(dir).mtimeMs;
  let isFirstModified = true;

  fs.watch(dir, (eventType) => {
    if (eventType === type) {
      const oldConfig = global.GoatBot[prop];

      // wait 200ms to reload config
      setTimeout(() => {
        try {
          // if file change first time (when start bot, maybe you know it's called when start bot?) => not reload
          if (isFirstModified) {
            isFirstModified = false;
            return;
          }
          // if file not change => not reload
          if (lastModified === fs.statSync(dir).mtimeMs) {
            return;
          }
          global.GoatBot[prop] = JSON.parse(fs.readFileSync(dir, 'utf-8'));
          log.success(logName, `Reloaded ${dir.replace(process.cwd(), "")}`);
        }
        catch (err) {
          log.warn(logName, `Can't reload ${dir.replace(process.cwd(), "")}`);
          global.GoatBot[prop] = oldConfig;
        }
        finally {
          lastModified = fs.statSync(dir).mtimeMs;
        }
      }, 200);
    }
  });
};

watchAndReloadConfig(dirConfigCommands, 'change', 'configCommands', 'CONFIG COMMANDS');
watchAndReloadConfig(dirConfig, 'change', 'config', 'CONFIG');

global.GoatBot.envGlobal = global.GoatBot.configCommands.envGlobal;
global.GoatBot.envCommands = global.GoatBot.configCommands.envCommands;
global.GoatBot.envEvents = global.GoatBot.configCommands.envEvents;

// ———————————————— LOAD LANGUAGE ———————————————— //
const getText = global.utils.getText;

// ———————————————— AUTO RESTART ———————————————— //
  if (config.autoRestart) {
    const time = config.autoRestart.time;
    if (!isNaN(time) && time > 0) {
      utils.log.info("AUTO RESTART", getText("Goat", "autoRestart1", utils.convertTime(time, true)));
      setTimeout(() => {
        utils.log.info("AUTO RESTART", "Restarting...");
        process.exit(2);
      }, time);
    }
    else if (typeof time == "string" && time.match(/^((((\d+,)+\d+|(\d+(\/|-|#)\d+)|\d+L?|\*(\/\d+)?|L(-\d+)?|\?|[A-Z]{3}(-[A-Z]{3})?) ?){5,7})$/gmi)) {
      utils.log.info("AUTO RESTART", getText("Goat", "autoRestart2", time));
      const cron = require("node-cron");
      cron.schedule(time, () => {
        utils.log.info("AUTO RESTART", "Restarting...");
        process.exit(2);
      });
    }
  }

  // ———————————————— CHECK UPDATE REFUSE EXPIRY ———————————————— //
  setInterval(() => {
    if (global.updateRefuseUntil && Date.now() > global.updateRefuseUntil) {
      // Refuse period expired, re-enable update requirement
      if ((global.updateAvailable && global.updateAvailable.newVersion) || (global.GoatBot.updateAvailable && global.GoatBot.updateAvailable.newVersion)) {
        if (global.updateAvailable) {
          global.updateAvailable.hasUpdate = true;
        }
        if (global.GoatBot.updateAvailable) {
          global.GoatBot.updateAvailable.hasUpdate = true;
        }
        global.updateRefuseUntil = null;
        global.GoatBot.updateRefuseUntil = null;
        // Reset notification tracking to allow new notifications
        global.updateNotificationSent = {
          users: new Set(),
          admins: new Set()
        };
        utils.log.warn("UPDATE", "Update refuse period expired. Update requirement re-enabled.");
      }
    }
  }, 60000); // Check every minute

(async () => {
  // Gmail functionality removed
  global.utils.sendMail = () => Promise.reject(new Error("Gmail not configured"));
  global.utils.transporter = null;

  // ———————————————— INITIALIZE GITHUB SYNC ———————————————— //
  if (config.githubIntegration?.enable) {
    try {
      const githubSync = await utils.initGitHubSync(config);
      if (githubSync && githubSync.initialized) {
        const testResult = await githubSync.testConnection();
        if (testResult.success) {
          log.info("GITHUB", "GitHub integration ready");
        } else {
          log.warn("GITHUB", "GitHub connection failed:", testResult.message);
        }
      }
    } catch (error) {
      log.error("GITHUB", "Failed to initialize GitHub sync:", error.message);
    }
  }

  // ———————————————— CHECK VERSION ———————————————— //
  const { data: { version } } = await axios.get("https://raw.githubusercontent.com/sheikhtamimlover/ST-BOT/main/package.json");
  const currentVersion = require("./package.json").version;
  if (compareVersion(version, currentVersion) === 1) {
    global.updateAvailable.hasUpdate = true;
    global.updateAvailable.newVersion = version;
    global.GoatBot.updateAvailable.hasUpdate = true;
    global.GoatBot.updateAvailable.newVersion = version;

    // Reset notification tracking when new update detected
    global.updateNotificationSent = {
      users: new Set(),
      admins: new Set()
    };

    utils.log.master("NEW VERSION", getText(
      "Goat",
      "newVersionDetected",
      colors.gray(currentVersion),
      colors.hex("#eb6a07", version),
      colors.hex("#eb6a07", "node update")
    ));
    utils.log.warn("UPDATE ENFORCEMENT", "Bot will require update before responding to users");
  } else {
    // No update available, ensure flags are false
    global.updateAvailable.hasUpdate = false;
    global.updateAvailable.newVersion = null;
    global.GoatBot.updateAvailable.hasUpdate = false;
    global.GoatBot.updateAvailable.newVersion = null;
  }

  // ———————————————————— LOGIN ———————————————————— //
  require(`./bot/login/login.js`);
})();

function compareVersion(version1, version2) {
  const v1 = version1.split(".");
  const v2 = version2.split(".");
  for (let i = 0; i < 3; i++) {
    if (parseInt(v1[i]) > parseInt(v2[i]))
      return 1; // version1 > version2
    if (parseInt(v1[i]) < parseInt(v2[i]))
      return -1; // version1 < version2
  }
  return 0; // version1 = version2
}
