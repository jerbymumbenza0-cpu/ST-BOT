# Version française — ST-BOT

Le français est maintenant la langue par défaut du traitement des commandes et de l'agent STAI.

- Le gestionnaire utilise `fr` comme code de langue.
- Lorsqu'une commande possède une traduction française, elle est prioritaire.
- Lorsqu'une commande ne possède pas encore de traduction française, le bot conserve son texte anglais d'origine en solution de secours. Les traductions de toutes les commandes ne sont donc pas encore intégralement réalisées.
- L'agent STAI répond en français par défaut et ne passe à une autre langue que si l'utilisateur le demande explicitement.

Pour démarrer : `npm install`, puis `npm start` comme dans le projet d'origine.
